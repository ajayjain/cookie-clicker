var cookie;
var cookieCountText;
var clicks;

window.onload = function() {
    Initialize();
};

function Initialize() { 
    // What will we put here?
    
}

function clicked() {
    // What about here?
}

